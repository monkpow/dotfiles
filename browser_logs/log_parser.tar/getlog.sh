#!/bin/bash

DATE=`date -d "1 day ago" +"%Y%m%d"`
LOGHOME=/home/home02/webstats/input/bem_logs
PREFIX=browser_data_wmwl36ppa_
POSTFIX=.gz
FILELOC=$LOGHOME/$DATE/$PREFIX$DATE$POSTFIX
OUTPUTDIR=/home/home01/nkrimm/docroot/browserStats
WORKINGDIR=/home/home01/nkrimm/tmp


cp $FILELOC logs
gunzip -f logs/$PREFIX$DATE$POSTFIX
rm log
ln -s logs/$PREFIX$DATE log

#/home/home01/nkrimm/docroot/browserStats/log_parser.php > /home/home01/nkrimm/docroot/browserStats/$DATE.html
#/home/home01/nkrimm/docroot/browserStats/compare.sh
#/home/home01/nkrimm/docroot/browserStats/createIndex.sh > /home/home01/nkrimm/docroot/browserStats/index.html



