
ROOTDIR=~/docroot/browserStats
TMPDIR=$ROOTDIR/tmp


cd $TMPDIR

cut -d \" -f6 compare.txt | sort -d -u >> compare.nice 
cut -d \" -f6 $ROOTDIR/log | sort -d -u >> log.nice
diff compare.nice log.nice > $ROOTDIR/uncaptured_browsers.txt

