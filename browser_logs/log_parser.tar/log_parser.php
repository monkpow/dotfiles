#!/usr/bin/php -q

<?php

class useragent{
				var $name;
				var $grepKey;
				var $count;
				var $family;
				var $OS;
				var $per_cent;


		 function init($_OS,$_family,$_name,$_grepKey){
							$this->OS=$_OS;
							$this->name=$_name;
							$this->grepKey=$_grepKey;
							$this->family=$_family;
							} 

			function setCount($_count){ $this->count=$_count; }
			function setPerCent($_per_cent){$this->per_cent=$_per_cent;}
			function getName(){ return $this->name; }
			function getKey(){ return $this->grepKey; }
		}


$OUTFILE = "tmp/compare.txt"; #text file used to capture matching lines. Used as input to process to find unmatched lines
$BROWSERLIST = array();  # create an array of browser objects
$TOTAL_LINES=shell_exec('cat log | wc -l');



$MSIE60XPSP2=new useragent();
$MSIE60XPSP2->init("Windows", "IE", "MS IE 6.0 XP SP2", "grep 'MSIE 6.0; Windows NT 5.1; SV1'" ,$BROWSERLIST);
array_push($BROWSERLIST,$MSIE60XPSP2);

$MSIE60XP=new useragent();
$MSIE60XP->init("Windows", "IE", "MS IE 6.0 XP", "grep 'MSIE 6.0; Windows NT 5.1' | grep -v 'SV1'");
array_push($BROWSERLIST,$MSIE60XP);

$MSIE602K=new useragent();
$MSIE602K->init("Windows", "IE", "MS IE 6.0 2K", "grep 'MSIE 6.0; Windows NT 5.0' ");
array_push($BROWSERLIST,$MSIE602K);

$MSIE60NT=new useragent();
$MSIE60NT->init("Windows", "IE", "MS IE 6.0 NT", "grep 'MSIE' | grep '6.0' | grep 'Windows NT' | grep -v 'Windows NT 5'");
array_push($BROWSERLIST,$MSIE60NT);

$MSIE6098=new useragent();
$MSIE6098->init("Windows", "IE", "MS IE 6.0 98", "grep 'MSIE' | grep '6.0' | grep 'Windows 98' | grep -v 'Windows 98 5'");
array_push($BROWSERLIST,$MSIE6098);

$MSIE6095=new useragent();
$MSIE6095->init("Windows", "IE", "MS IE 6.0 95", "grep 'MSIE' | grep '6.0' | grep 'Windows 95'");
array_push($BROWSERLIST,$MSIE6095);


$MSIE55XP=new useragent();
$MSIE55XP->init("Windows", "IE", "MS IE 5.5 XP", "grep 'MSIE 5.5; Windows NT 5.1' | grep -v 'SV1'");
array_push($BROWSERLIST,$MSIE55XP);

$MSIE552K=new useragent();
$MSIE552K->init("Windows", "IE", "MS IE 5.5 2K", "grep 'MSIE 5.5; Windows NT 5.0' ");
array_push($BROWSERLIST,$MSIE552K);

$MSIE55NT=new useragent();
$MSIE55NT->init("Windows", "IE", "MS IE 5.5 NT", "grep 'MSIE' | grep '5.5' | grep 'Windows NT' | grep -v 'Windows NT 5'");
array_push($BROWSERLIST,$MSIE55NT);

$MSIE5598=new useragent();
$MSIE5598->init("Windows", "IE", "MS IE 5.5 98", "grep 'MSIE' | grep '5.5' | grep 'Windows 98' | grep -v 'Windows 98 5'");
array_push($BROWSERLIST,$MSIE5598);

$MSIE5595=new useragent();
$MSIE5595->init("Windows", "IE", "MS IE 5.5 95", "grep 'MSIE' | grep '5.5' | grep 'Windows 95'");
array_push($BROWSERLIST,$MSIE5595);


$MSIE50NT=new useragent();
$MSIE50NT->init("Windows", "IE", "MS IE 5.0 NT", "grep 'MSIE' | grep '5.0' | grep 'Windows NT' | grep -v 'Windows NT 5'");
array_push($BROWSERLIST,$MSIE50NT);

$MSIE5098=new useragent();
$MSIE5098->init("Windows", "IE", "MS IE 5.0 98", "grep 'MSIE' | grep '5.0' | grep 'Windows 98' | grep -v 'Windows 98 5'");
array_push($BROWSERLIST,$MSIE5098);

$MSIE5095=new useragent();
$MSIE5095->init("Windows", "IE", "MS IE 5.0 95", "grep 'MSIE' | grep '5.0' | grep 'Windows 95'");
array_push($BROWSERLIST,$MSIE5095);

# Browers - Mozilla

$FIREFOXXP=new useragent();
$FIREFOXXP->init("Windows", "MOZ", "Firefox (all versions) XP", "grep 'Gecko' | grep 'Firefox/' | grep 'Windows NT 5.1'" );
array_push($BROWSERLIST,$FIREFOXXP);

$FIREFOX2K=new useragent();
$FIREFOX2K->init("Windows", "MOZ", "Firefox (all versions) 2K", "grep 'Gecko' | grep 'FireFox' | grep 'Windows NT 5.0' ");
array_push($BROWSERLIST,$FIREFOX2K);

$FIREFOXNT=new useragent();
$FIREFOXNT->init("Windows", "MOZ", "Firefox (all versions) NT", "grep 'Gecko' | grep 'Firefox' | grep 'Windows NT' | grep -v 'Windows NT 5'");
array_push($BROWSERLIST,$FIREFOXNT);


$FIREFOX98=new useragent();
$FIREFOX98->init("Windows", "MOZ", "Firefox (all versions) 98", "grep 'Gecko' | grep 'Firefox' | grep 'Windows 98' | grep -v 'Windows 98 5'");
array_push($BROWSERLIST,$FIREFOX98);

$FIREFOX95=new useragent();
$FIREFOX95->init("Windows", "MOZ", "Firefox (all versions) 95", "grep 'Gecko' | grep 'Firefox' | grep 'Windows 95'");
array_push($BROWSERLIST,$FIREFOX95);

# Netscape 


$MOZXP=new useragent();
$MOZXP->init("Windows", "MOZ", "Mozilla XP", "grep 'Gecko' | grep 'Mozilla/5.0'  | grep -v 'Firefox/' | grep 'Windows NT 5.1'" );
array_push($BROWSERLIST,$MOZXP);

$MOZ2K=new useragent();
$MOZ2K->init("Windows", "MOZ", "Mozilla 2K", "grep 'Gecko' | grep 'Mozilla/5.0'  | grep -v 'FireFox' | grep 'Windows NT 5.0' ");
array_push($BROWSERLIST,$MOZ2K);

$MOZNT=new useragent();
$MOZNT->init("Windows", "MOZ", "Mozilla NT", "grep 'Gecko' | grep 'Mozilla/5.0'  | grep -v 'Firefox' | grep 'Windows NT' | grep -v 'Windows NT 5'");
array_push($BROWSERLIST,$MOZNT);

$MOZ98=new useragent();
$MOZ98->init("Windows", "MOZ", "Mozilla 98", "grep 'Gecko' | grep 'Mozilla/5.0'  | grep -v 'Firefox' | grep 'Windows 98' | grep -v 'Windows 98 5'");
array_push($BROWSERLIST,$MOZ98);

$MOZ95=new useragent();
$MOZ95->init("Windows", "MOZ", "Mozilla 95", "grep 'Gecko' | grep 'Mozilla/5.0'  | grep -v 'Firefox' | grep 'Windows 95'");
array_push($BROWSERLIST,$MOZ95);


$NETSCAPE7XP=new useragent();
$NETSCAPE7XP->init("Windows", "MOZ", "Netscape 7 XP", "grep 'Gecko' | grep 'Netscape/7'  |  grep 'Windows NT 5.1'" );
array_push($BROWSERLIST,$NETSCAPE7XP);

$NETSCAPE72K=new useragent();
$NETSCAPE72K->init("Windows", "MOZ", "Netscape 7 2K", "grep 'Gecko' | grep 'Netscape/7'  | grep 'Windows NT 5.0' ");
array_push($BROWSERLIST,$NETSCAPE72K);

$NETSCAPE7NT=new useragent();
$NETSCAPE7NT->init("Windows", "MOZ", "Netscape 7 NT", "grep 'Gecko' | grep 'Netscape/7'  |  grep 'Windows NT' | grep -v 'Windows NT 5'");
array_push($BROWSERLIST,$NETSCAPE7NT);

$NETSCAPE798=new useragent();
$NETSCAPE798->init("Windows", "MOZ", "Netscape 7 98", "grep 'Gecko' | grep 'Netscape/7'  |  grep 'Windows 98' | grep -v 'Windows 98 5'");
array_push($BROWSERLIST,$NETSCAPE798);



$NETSCAPE795=new useragent();
$NETSCAPE795->init("Windows", "MOZ", "Netscape 7 95", "grep 'Gecko' | grep 'Netscape/7'  |  grep 'Windows 95'");
array_push($BROWSERLIST,$NETSCAPE795);


$NETSCAPE6XP=new useragent();
$NETSCAPE6XP->init("Windows", "MOZ", "Netscape 6 XP", "grep 'Gecko' | grep 'Netscape/6'  |  grep 'Windows NT 5.1'" );
array_push($BROWSERLIST,$NETSCAPE6XP);

$NETSCAPE62K=new useragent();
$NETSCAPE62K->init("Windows", "MOZ", "Netscape 6 2K", "grep 'Gecko' | grep 'Netscape/6'  | grep 'Windows NT 5.0' ");
array_push($BROWSERLIST,$NETSCAPE62K);

$NETSCAPE6NT=new useragent();
$NETSCAPE6NT->init("Windows", "MOZ", "Netscape 6 NT", "grep 'Gecko' | grep 'Netscape/6'  |  grep 'Windows NT' | grep -v 'Windows NT 5'");
array_push($BROWSERLIST,$NETSCAPE6NT);

$NETSCAPE698=new useragent();
$NETSCAPE698->init("Windows", "MOZ", "Netscape 6 98", "grep 'Gecko' | grep 'Netscape/6'  |  grep 'Windows 98' | grep -v 'Windows 98 5'");
array_push($BROWSERLIST,$NETSCAPE698);


$NETSCAPE695=new useragent();
$NETSCAPE695->init("Windows", "MOZ", "Netscape 6 95", "grep 'Gecko' | grep 'Netscape/6'  |  grep 'Windows 95'");
array_push($BROWSERLIST,$NETSCAPE695);


# MAC BROWSERS

$SAFARI=new useragent();
$SAFARI->init("MAC", "SAFARI", "Safari", "grep '(KHTML, like Gecko)' | grep 'Safari' ");
array_push($BROWSERLIST,$SAFARI);

$MOZILLA=new useragent();
$MOZILLA->init("MAC", "MOZ", "Mozilla", "grep 'Mozilla/5.0' | grep 'Macintosh' ");
array_push($BROWSERLIST,$MOZILLA);

$MACIE52=new useragent();
$MACIE52->init("MAC", "IE", "MSIE 5.2 Mac", "grep 'MSIE 5.2' | grep 'Mac_PowerPC' ");
array_push($BROWSERLIST,$MACIE52);


$MACIE51=new useragent();
$MACIE51->init("MAC", "IE", "MSIE 5.1", "grep 'MSIE 5.1' | grep 'Mac_PowerPC' ");
array_push($BROWSERLIST,$MACIE51);

$MACIE50=new useragent();
$MACIE50->init("MAC", "IE", "MSIE 5.0", "grep 'MSIE 5.0' | grep 'Mac_PowerPC' ");
array_push($BROWSERLIST,$MACIE50);

$TOTAL_COUNTED=0;
$TOTAL_PC=0;
$TOTAL_MAC=0;
$TOTAL_IE=0;
$TOTAL_MOZ=0;
$TOTAL_SAFARI=0;

## Prepare browser array

for($i=0;$i<sizeof($BROWSERLIST);$i++){
				$grepString="cat log | " . $BROWSERLIST[$i]->getKey() . " | wc -l ";
				$BROWSERLIST[$i]->setCount(shell_exec($grepString));
				#create a new file to compare with log, and catch which groupings are missed
				$EXEC_STR="cat log | ". $BROWSERLIST[$i]->getKey() . " >> " . $OUTFILE;
				exec($EXEC_STR);
				$BROWSERLIST[$i]->setPerCent((round($BROWSERLIST[$i]->count/$TOTAL_LINES,4))*100);
				$TOTAL_COUNTED=$TOTAL_COUNTED+$BROWSERLIST[$i]->count;
				
				switch($BROWSERLIST[$i]->family){
					case "MOZ": 
							$TOTAL_MOZ+=$BROWSERLIST[$i]->count;
							break;
					case "IE":
							$TOTAL_IE+=$BROWSERLIST[$i]->count;
							break;
					case "SAFARI":
							$TOTAL_SAFARI+=$BROWSERLIST[$i]->count;
							break;
				}
				
				switch($BROWSERLIST[$i]->OS){
					case "Windows": 
							$TOTAL_PC=$TOTAL_PC+$BROWSERLIST[$i]->count;
							break;
					case "MAC":
							$TOTAL_MAC+=$BROWSERLIST[$i]->count;
							break;
				}


				}

#CREATER LIST OF MISSING USER-AGENTS

#exec("compare.sh");

## print browser info to screen

#function startHTML(){
# prints out top of HTML document
echo '<html>';
echo '<head>';
echo '<link rel="stylesheet" href="style.css" />';
#echo '<style>';
#echo 'body, table, td {font-family:arial, sans-serif;}';
#echo 'td{width:250px; text-align:left;}';
#echo 'table, td {border:1px solid black}';
#echo '</style>';
echo '</head>';
echo '<body>';
echo '<h1>Browser Stats</h1>';
#}



#function printTotals(){
echo "<h2> Total Sessions: " . $TOTAL_LINES . "</h2>";
echo "<h2> Total Counted: " . $TOTAL_COUNTED . "</h2>";
echo "<h2> Per Cent Counted by this script: " . round($TOTAL_COUNTED/$TOTAL_LINES,4)*100 . "</h2>";
echo "<h2> Total PC : " . round($TOTAL_PC/$TOTAL_LINES,4)*100 . "</h2>";
echo "<h2> Total MAC : " . round($TOTAL_MAC/$TOTAL_LINES,4)*100 . "</h2>";
echo "<h2> Total IE : " . round($TOTAL_IE/$TOTAL_LINES,4)*100 . "</h2>";
echo "<h2> Total MOZ : " . round($TOTAL_MOZ/$TOTAL_LINES,4)*100 . "</h2>";
echo "<h2> Total Safari : " . round($TOTAL_SAFARI/$TOTAL_LINES,4)*100 . "</h2>";
#}

#function printTable(){
echo "<table id=\"browserTab\">";
echo "<tr><th>OS</th><th>Family</th><th>Version</th><th>Total</th><th>Per Cent</th></tr>";
for($i=0;$i<sizeof($BROWSERLIST);$i++){
echo "<tr><td>" . $BROWSERLIST[$i]->OS . "</td><td>" . $BROWSERLIST[$i]->family . "</td><td>" . $BROWSERLIST[$i]->name . "</td><td>" . $BROWSERLIST[$i]->count . "</td><td>" . $BROWSERLIST [$i]->per_cent . "</td></tr>\n" ;
}
echo "</table>";
#}

#function printEndPage(){ 
echo "</body>\n</html>"; 
#}



#startHTML();
#printTotals();
#printTable();
#printEndPage();



// Exit correctly
#exit(0);
?>
