#!/bin/bash

echo "<html><head><link rel=\"stylesheet\" href=\"style.css\" /></head><body>"
echo "<h1>List of browser logs by date</h1>"

alias ls="ls" # reset alias
for file in `ls *html` ; do
	echo "<li><a href=\"$file\">$file</a></li>"
done;
for file in `ls *txt` ; do
	echo "<li><a href=\"$file\">$file</a></li>"
done;
echo "</body></html>"
