#!/usr/bin/python2.5

# built for a specific refactoring task
# run after pathwalker.py
# rippping through all JSPs
# check changed files for duplicate nodes in destination files
# if multiple nodes are found, compare nodes
# if nodes are same, remove multiple c:sets, but leave all comments
# if nodes are different, flag, and (maybe?) return nodes to previous file


from __future__ import with_statement
import fnmatch
import os
import sys
import fileinput
import re

def locate(pattern, root=os.getcwd()):
  """
  looks for files matching a certain pattern ('*jsp') in a specific directory
  """
  for path, dirs, files in os.walk(root):
    for filename in [os.path.abspath(os.path.join(path, filename)) for filename in files if fnmatch.fnmatch(filename, pattern)]:
      yield filename

inserted_text=re.compile('<c:set var="moduleNode" scope="request">(?P<moduleNode>[^<]*)</c:set>(?P<niks_comment>.*)')

def processSourceJsp(jsp):
  working_file=open(jsp)
  file_list=working_file.readlines()
  operations_list=[]
  for i in range(0,len(file_list)):
    line=file_list[i-1]
    match=inserted_text.search(line)
    print "matched:", match, line

    if match is not None and len(match.group("niks_comment"))!=0:
      # split inserted comments from rest of file
      operations_list.append(line)
      file_list[i-1]="" 
  if len(operations_list) > 1:    
    # now i have a list of inserted c:sets, need to compare them and munge strings where appropriate, and leave as is if not 
    result=process_operations_list(operations_list)
    #combine result of processed regexs to stripped files
    for line in result:
      file_list.insert(0,line)
    working_file.close()
    clobber_file=open(jsp,'w')
    clobber_file.writelines(file_list)
    clobber_file.close()


def process_operations_list(list):
  prev={'line':None,'moduleNode':None,'comment':None}
  list.sort()
  inserted_text=re.compile('<c:set var="moduleNode" scope="request">(?P<moduleNode>[^<]*)</c:set>(?P<niks_comment>.*)')
  file_pattern=re.compile(".*yanked from file.\s*'([^']*)'.*") 

  for i in range(0, len(list)):
    line=list[i]
    get_inserted_text=inserted_text.match(line)
    moduleNode=get_inserted_text.group('moduleNode')
    comment=get_inserted_text.group('niks_comment')

    if moduleNode==prev['moduleNode']:  # we've got a duplicate entry, munge lines and comments
      get_fname_from_comment=file_pattern.match(comment)

      if get_fname_from_comment is not None:
        list[i]=list[i-1].replace("' }}", "' ,'"+get_fname_from_comment.group(1)+"' }}") # munge file comments from previous line to this line
        list[i-1]=""
        #print "r",list[i]
    prev={'line':line, 'moduleNode':moduleNode, 'comment':comment}
    
    #lets now remove blank elements
  #for n in list:
    #if n=="":
      #list.remove(n) 
  return list


if __name__ == '__main__':
  for jsp in locate("*.jsp", '/home/nkrimm/depots/austin/depots/arch-34/webapp/ROOT.war/'):
    if 'pui' not in jsp and 'devtools' not in jsp: processSourceJsp(jsp)
       
