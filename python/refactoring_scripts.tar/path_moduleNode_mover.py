#!/usr/bin/python2.5

# built for a specific refactoring task
# distribute ${moduleNode} to individual CMSnode calls
# do tags separately

from __future__ import with_statement
import fnmatch
import os
import sys
import fileinput
import re

def locate(pattern, root=os.getcwd()):
  """
  looks for files matching a certain pattern ('*jsp') in a specific directory
  """
  for path, dirs, files in os.walk(root):
    for filename in [os.path.abspath(os.path.join(path, filename)) for filename in files if fnmatch.fnmatch(filename, pattern)]:
      yield filename


def processSourceJsp(jsp):
  if 'var="moduleNode"' in open(jsp).readlines()[0]:
    pattern=re.compile(r'<c:set var="moduleNode"\s*(scope="request")?>(?P<moduleNode>[^<]*)</c:set>')
    newFile=open(jsp).readlines()
    george=pattern.match(open(jsp).readlines()[0]) 
    if george.group('moduleNode') is not None:
      newFile[0]=""
      # here we're going to punch george into cms:message and cmsNode places
      for line in range(0,len(newFile)):
        if 'cms:message' in newFile[line]:        
          newFile[line]=newFile[line].replace('node="','node="'+george.group('moduleNode')+'.')
        if 'cmsNode=' in newFile[line]:
          newFile[line]=newFile[line].replace('cmsNode="','cmsNode="'+george.group('moduleNode')+'.')
      #print jsp
      #print george.group('moduleNode') 
      #print newFile
      clobber_file=open(jsp,'w')
      clobber_file.writelines(newFile)
      clobber_file.close()


if __name__ == '__main__':
  #for jsp in locate("*.jsp", '/home/nkrimm/depots/austin/depots/arch-34/webapp/ROOT.war/WEB-INF/module'):
    #if 'pui' not in jsp and 'devtools' not in jsp: processSourceJsp(jsp)
  for jsp in locate("*.jsp", '/home/nkrimm/depots/austin/depots/arch-34/webapp/ROOT.war/POS'):
    if 'pui' not in jsp and 'devtools' not in jsp: processSourceJsp(jsp)
       
