#!/usr/bin/python2.5

# built for a specific refactoring task
# rippping through all JSPs
# and extracting nodes from source files 
# and pushing them down to child files

# recent changes
# add comment to mark changed lines
# add comment to modified lines
# [:-1]chops last character of last line on solitaire.jsp
# solve for paths with ?querystings
# remove pui and devtools files

# remaining issues
# solve for paths with ${}adynamic paths

from __future__ import with_statement
import fnmatch
import os
import sys
import fileinput
import re

def locate(pattern, root=os.getcwd()):
  """
  looks for files matching a certain pattern ('*jsp') in a specific directory
  """
  for path, dirs, files in os.walk(root):
    for filename in [os.path.abspath(os.path.join(path, filename)) for filename in files if fnmatch.fnmatch(filename, pattern)]:
      yield filename


def processSourceJsp(jsp):
  for line in fileinput.input(jsp,inplace=1,backup='.bak'): 
    pattern=re.compile('(<render:(?:module|include)(?:.*?(?:src="(?P<src>[^"]*)")|.*?(?:node="(?P<node>[^"]*)")|.*?(?:region="(?P<region>[^"]*)"))+)')
    match=pattern.search(line)
    if match is not None and match.group('node') is not None:
      src_fname=jsp
      dest_fname=match.group('src') 
      dest_fname=dest_fname.split("?")[0] # strips query string

      node=match.group('node')
      replacement_tag='<c:set var="moduleNode" scope="request">'+match.group('node')+'</c:set>'
      include_from_comment="<%--{{ nmk_cms_replace: line yanked from file '"+jsp.replace("/home/nkrimm/depots/austin/depots/arch-34/webapp/ROOT.war/","")+"' }}--%>"
      include_to_comment="<%--{{ nmk_cms_replace: node yanked to file '"+dest_fname+"' }}--%>"
      try: # this block attempts to poke this node into destingation file, and if successful, removes node from current line
        destination_file=open("."+dest_fname)
        r=destination_file.readlines()
        destination_file.close()
        r.insert(0,""+replacement_tag+"\t\t" + include_from_comment +"\n");
        dest_file=open("."+dest_fname,"w")
        dest_file.writelines(r);
        dest_file.close()
        local_pattern=re.compile('node="[^"]*"')
        line=local_pattern.sub("", line)
        line= line[:-1] + "\t\t" + include_to_comment +"\n"
      except IOError:
        with open('log.txt','a') as log:
          log.write("\nerror:\n"+str(IOError.message)+"\n"+str(locals()))
    if line[-1]==">": line = line+" "      
    print line[:-1]

if __name__ == '__main__':
  for jsp in locate("*.jsp", '/home/nkrimm/depots/austin/depots/arch-34/webapp/ROOT.war/'):
    if 'pui' not in jsp and 'devtools' not in jsp: processSourceJsp(jsp)
       
