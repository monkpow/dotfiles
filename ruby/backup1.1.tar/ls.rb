#!/usr/local/bin/ruby
cols=[]
`ls -Al`.each |dm|
puts dm
end
dt.each do |line|
cols=line.split(/\s[^\S]*/)
#cols.each_with_index do |col,i|
 #puts "#{i}:#{col} "
#end
puts "#{cols[5]}\s#{cols[6]}\t#{cols[7]}\t#{cols[8]}"#\t\t\t\t#{cols[0]}\s"
end

