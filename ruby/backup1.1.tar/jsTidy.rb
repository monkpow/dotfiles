#!/usr/local/bin/ruby

@shift_width=2
@softtabs=true
@current_indent=0
@previous_line=""


def indent
  #increase could be negative
  @current_indent=@current_indent+1
end

def outdent
  #increase could be negative
  @current_indent=@current_indent-1
end

def get_indent
  stringin=""
  @current_indent.times {
    stringin=stringin+" "
  }
  return stringin
end

while(line=gets)
  line.gsub!(/^\s*/,"")
  if line =~ /^(function)\s*([^(]*)*\)/
    line= "#{$2}=#{$1}(#{$3})"
  end
  if line =~ /\{\s*$/ 
    indent
  end
  if line =~ /^\s*/ && @previous_line =~ /^\s*$/
    puts "next"
  end
  
  @previous_line=line
  puts get_indent + line

end
